# Final Exam

## Q1
![q1](Q1)
## Q2
![q2](Q2)

## Q3
![q3](Q3)